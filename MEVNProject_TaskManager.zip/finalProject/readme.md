
# MEVN Stack App Project

This project aims to create an integrated application using Vue.js and Node.js, modeled closely on examples provided in Chapter 9 of the course materials. The application integrates with Express and MongoDB to provide a complete client-side and server-side experience.

---

## Project Objectives

- **Collaboration**: This project is designed as a collaborative classroom effort where students apply the concepts learned in previous lessons.
- **Customization**: Students will analyze and modify the provided code to create a unique application based on the group’s desired outcomes.
- **Research**: Additional research will be required for concepts not fully covered in the textbook, utilizing external resources like W3Schools, Stack Overflow, and AI-assisted tools.
- **Iterative Development**: Code will be developed, tested, and refined through multiple iterations to achieve the final application.

---

## Features

- **Task Management**:
  - Add tasks with a title, description, and date assigned.
  - Modify task details directly in the UI.
  - Remove tasks from the list.
  
- **Database Integration**:
  - All task data is stored in MongoDB.
  - RESTful API endpoints handle CRUD operations.

- **Front-End**:
  - Built with Vue.js, including reusable components like `Element` for task management.
  - Dynamic rendering of tasks and real-time updates.

- **Back-End**:
  - Node.js and Express for server-side logic.
  - Mongoose for database schema and interaction.

---

## Key Components

### GlobalApp.js

- Manages the main Vue.js app state and data.
- Features methods to handle task creation, modification, and deletion.
- Retrieves tasks from the server on initialization.

### app.js (Back-End)

- Sets up the Express server and MongoDB connection.
- Defines RESTful routes for:
  - Adding tasks (`POST /list`)
  - Retrieving tasks (`GET /list`)
  - Updating tasks (`PUT /list`)
  - Deleting tasks (`DELETE /list`)
- Includes middleware for error handling.

### Element.js

- Vue.js component for individual task items.
- Provides interactive elements for:
  - Modifying task title and description.
  - Updating the assigned date.
  - Removing tasks.

---

## Development Workflow

1. **Planning**: Define the desired user interface and functionality, including what data will be stored and how it will be displayed.
2. **Coding**:
   - Start with the provided template code.
   - Customize and extend as needed.
3. **Testing**:
   - Continuously test the application functionality, focusing on CRUD operations and UI interactivity.
   - Address bugs and refine features.
4. **Research**:
   - Explore external resources for new or unfamiliar concepts.
   - Replace deprecated callback functions with Promises.
5. **Submission**:
   - Submit a zipped folder containing project files and screenshots.
   - Include a GitHub URL for the project repository.

---

## Installation and Setup

1. **Clone the Repository**:
   ```bash
   git clone <repository-url>
   cd <project-directory>
   ```
2. **Install Dependencies**:
   ```bash
   npm install
   ```
3. **Set Up MongoDB**:
   - Ensure MongoDB is installed and running locally.
   - Use the database name `mydb_test` as specified in `app.js`.
4. **Run the Application**:
   ```bash
   npm start
   ```
   - Access the application at `http://localhost:3000/`.

---

## External Resources

- **W3Schools**: General tutorials on HTML, CSS, JavaScript, and Node.js.
- **Stack Overflow**: Community-driven solutions to common programming problems.
- **AI Tools**: Use Google or Bing for additional insights and debugging help.

---

## Notes

- Collaboration and individual submissions are both required. Ensure your project reflects the group’s ideas while adhering to the submission guidelines.
- Testing is essential. Iterate on your code to achieve optimal functionality and user experience.

---

## Submission Guidelines

- **Files**: Submit a zipped folder containing all project files.
- **Screenshots**: Include screenshots of the application in action.
- **GitHub URL**: Provide a link to the project repository.

---

## Acknowledgements

This project is based on examples from Chapter 9 of the course textbook. Special thanks to the instructor and classmates for collaborative efforts and shared insights.

